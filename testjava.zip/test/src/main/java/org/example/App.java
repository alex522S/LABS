package org.example;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Calculator calc = new Calculator();
        Scanner sc = new Scanner(System.in);

        System.out.println("Введите два числа:");
        int a = sc.nextInt();
        int b = sc.nextInt();

        System.out.println("Сумма: " + calc.add(a, b));
        System.out.println("Разность: " + calc.subtract(a, b));
        System.out.println("Произведение: " + calc.multiply(a, b));

        try {
            System.out.println("Деление: " + calc.divide(a, b));
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("Первое число чётное? " + calc.isEven(a));
    }
}

