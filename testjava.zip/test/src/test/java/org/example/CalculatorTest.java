package org.example;

import org.testng.Assert;
import org.testng.annotations.Test;

import org.testng.annotations.DataProvider;

public class CalculatorTest {

    Calculator calc = new Calculator();

    // 1️⃣ Тест на сложение
    @Test(groups = {"math", "positive"})
    public void testAdd() {
        // ARRANGE
        int a = 5;
        int b = 7;
        int expected = 12;

        // ACT
        int result = calc.add(a, b);

        // ASSERT
        Assert.assertEquals(result, expected);
    }

    // 2️⃣ Тест на вычитание
    @Test(groups = {"math"})
    public void testSubtract() {
        int result = calc.subtract(10, 3);
        Assert.assertEquals(result, 7);
    }

    // 3️⃣ Тест на умножение
    @Test(groups = {"math"})
    public void testMultiply() {
        int result = calc.multiply(4, 5);
        Assert.assertEquals(result, 20);
    }

    // 4️⃣ Тест на деление
    @Test(groups = {"math"})
    public void testDivide() {
        double result = calc.divide(20, 4);
        Assert.assertEquals(result, 5.0);
    }

    // 5️⃣ Тест на деление на ноль (исключение)
    @Test(groups = {"exception"}, expectedExceptions = IllegalArgumentException.class)
    public void testDivideByZero() {
        calc.divide(10, 0);
    }

    // 6️⃣ Тест на чётность
    @Test(groups = {"logic"})
    public void testIsEven() {
        Assert.assertTrue(calc.isEven(8));
        Assert.assertFalse(calc.isEven(7));
    }

    // 7️⃣ Тест с DataProvider (проверка возведения в степень)
    @DataProvider(name = "powerData")
    public Object[][] powerData() {
        return new Object[][]{
                {2, 3, 8},
                {3, 2, 9},
                {5, 0, 1},
                {7, 1, 7}
        };
    }

    @Test(dataProvider = "powerData", groups = {"math", "param"})
    public void testPower(int base, int exp, int expected) {
        int result = calc.power(base, exp);
        Assert.assertEquals(result, expected);
    }

    // 8️⃣ Тест на отрицательные числа (пример граничных значений)
    @Test(groups = {"boundary"})
    public void testAddNegativeNumbers() {
        int result = calc.add(-5, -7);
        Assert.assertEquals(result, -12);
    }
}
